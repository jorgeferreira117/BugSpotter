const SecurityManager = require('./src/modules/SecurityManager.js');
module.exports = SecurityManager;