const ErrorHandler = require('./src/modules/ErrorHandler.js');
module.exports = ErrorHandler;