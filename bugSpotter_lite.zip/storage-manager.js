const StorageManager = require('./src/modules/StorageManager.js');
module.exports = StorageManager;